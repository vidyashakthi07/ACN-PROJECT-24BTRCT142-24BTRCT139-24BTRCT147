#!/usr/bin/env python3

import numpy as np
import pandas as pd

# ---------------------------------------------------
# 1. LOAD DATASETS
# ---------------------------------------------------

df1 = pd.read_csv(
    'Tuesday-WorkingHours.pcap_ISCX.csv',
    low_memory=False
)

df2 = pd.read_csv(
    'Wednesday-workingHours.pcap_ISCX.csv',
    low_memory=False
)

df3 = pd.read_csv(
    'Thursday-WorkingHours-Morning-WebAttacks.pcap_ISCX.csv',
    low_memory=False
)

# Combine datasets
dataset = pd.concat(
    [df1, df2, df3],
    ignore_index=True
)

print("Dataset shape:", dataset.shape)


# ---------------------------------------------------
# 2. CLEAN COLUMN NAMES
# ---------------------------------------------------

dataset.columns = dataset.columns.str.strip()


# ---------------------------------------------------
# 3. SEPARATE FEATURES AND TARGET
# ---------------------------------------------------

X = dataset.iloc[:, :-1].copy()
y = dataset.iloc[:, -1].copy()

# Clean target labels
y = y.astype(str).str.strip()

print("\nAttack classes:")
print(y.value_counts())


# ---------------------------------------------------
# 4. CONVERT FEATURES TO NUMERIC
# ---------------------------------------------------

X = X.apply(pd.to_numeric, errors='coerce')

# Replace infinity values with NaN
X.replace([np.inf, -np.inf], np.nan, inplace=True)


# ---------------------------------------------------
# 5. HANDLE MISSING VALUES
# ---------------------------------------------------

from sklearn.impute import SimpleImputer

imputer = SimpleImputer(strategy='mean')

X = imputer.fit_transform(X)


# ---------------------------------------------------
# 6. ENCODE TARGET LABELS
# ---------------------------------------------------

from sklearn.preprocessing import LabelEncoder

labelencoder_y = LabelEncoder()

y = labelencoder_y.fit_transform(y)

print("\nEncoded classes:")

for i, label in enumerate(labelencoder_y.classes_):
    print(i, "=", label)


# ---------------------------------------------------
# 7. TRAIN TEST SPLIT
# ---------------------------------------------------

from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.60,
    random_state=42,
    stratify=y
)

print("\nTraining samples:", X_train.shape[0])
print("Testing samples :", X_test.shape[0])


# ---------------------------------------------------
# 8. FEATURE SCALING
# ---------------------------------------------------

from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# ---------------------------------------------------
# 9. ELASTIC NET REGRESSION
# ---------------------------------------------------

from sklearn.linear_model import ElasticNet

regressor = ElasticNet(
    alpha=0.1,
    l1_ratio=0.5
)

regressor.fit(X_train, y_train)

y_pred = regressor.predict(X_test)


# ---------------------------------------------------
# 10. CONVERT PREDICTIONS TO CLASS LABELS
# ---------------------------------------------------

y_pred_class = np.rint(y_pred).astype(int)

y_pred_class = np.clip(
    y_pred_class,
    0,
    len(labelencoder_y.classes_) - 1
)


# ---------------------------------------------------
# 11. PERFORMANCE METRICS
# ---------------------------------------------------

from sklearn.metrics import (
    confusion_matrix,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    classification_report
)

cm = confusion_matrix(
    y_test,
    y_pred_class
)

accuracy = accuracy_score(
    y_test,
    y_pred_class
)

precision = precision_score(
    y_test,
    y_pred_class,
    average='weighted',
    zero_division=0
)

recall = recall_score(
    y_test,
    y_pred_class,
    average='weighted',
    zero_division=0
)

f1 = f1_score(
    y_test,
    y_pred_class,
    average='weighted',
    zero_division=0
)


# ---------------------------------------------------
# 12. DISPLAY RESULTS
# ---------------------------------------------------

print("\n==============================")
print("ELASTIC NET REGRESSION RESULTS")
print("==============================")

print("\nCONFUSION MATRIX")
print("==============================")
print(cm)

print("\nPERFORMANCE METRICS")
print("==============================")

print("Accuracy  : {:.4f}".format(accuracy))
print("Precision : {:.4f}".format(precision))
print("Recall    : {:.4f}".format(recall))
print("F1 Score  : {:.4f}".format(f1))

print("\nCLASSIFICATION REPORT")
print("==============================")

print(
    classification_report(
        y_test,
        y_pred_class,
        labels=np.unique(y_test),
        target_names=labelencoder_y.inverse_transform(
            np.unique(y_test)
        ),
        zero_division=0
    )
)